import RandomVerse from './components/RandomVerse';
import SpecificVerse from './components/SpecificVerse';

function App() {
  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>Bible Verse App</h1>
        <p style={styles.subtitle}>Find inspiration from the Bible</p>
        <div style={styles.verseSection}>
          <RandomVerse />
          <SpecificVerse />
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    background: 'linear-gradient(135deg, #6DD5FA, #FFFFFF)', // Soft gradient background for a modern look
  },
  card: {
    backgroundColor: '#fff',
    padding: '30px',
    borderRadius: '20px',
    boxShadow: '0 10px 30px rgba(0, 0, 0, 0.1)', // Subtle shadow for depth
    maxWidth: '600px',
    width: '100%',
    textAlign: 'center',
  },
  title: {
    fontSize: '32px',
    fontWeight: 'bold',
    color: '#2c3e50',
    fontFamily: "'Poppins', sans-serif", // Modern and clean font
    marginBottom: '10px',
  },
  subtitle: {
    fontSize: '18px',
    color: '#7f8c8d',
    fontFamily: "'Poppins', sans-serif",
    marginBottom: '30px',
  },
  verseSection: {
    display: 'flex',
    flexDirection: 'column',
    gap: '30px', // Spacing between the components
  },
};

export default App;
