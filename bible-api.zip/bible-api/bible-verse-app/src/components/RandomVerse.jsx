import { useState } from 'react';

function RandomVerse() {
  const [verse, setVerse] = useState('');

  const fetchRandomVerse = async () => {
    try {
      const response = await fetch('https://labs.bible.org/api/?passage=random&type=json');
      const data = await response.json();
      const randomVerse = `${data[0].bookname} ${data[0].chapter}:${data[0].verse} - "${data[0].text}"`;
      setVerse(randomVerse);
    } catch (error) {
      console.error('Error fetching verse:', error);
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Get a Random Bible Verse</h2>
      <button onClick={fetchRandomVerse} style={styles.button}>
        Get Random Verse
      </button>
      {verse && (
        <div style={styles.verseContainer}>
          <p style={styles.verse}>{verse}</p>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9f9f9',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    maxWidth: '500px',
    margin: '20px auto',
    textAlign: 'center',
  },
  heading: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: '20px',
    fontFamily: "'Poppins', sans-serif",
  },
  button: {
    padding: '12px 25px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '16px',
    fontFamily: "'Poppins', sans-serif",
    transition: 'background-color 0.3s ease',
  },
  buttonHover: {
    backgroundColor: '#45a049',
  },
  verseContainer: {
    marginTop: '20px',
    backgroundColor: '#fff',
    padding: '15px 20px',
    borderRadius: '10px',
    boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
    width: '100%',
    maxWidth: '400px',
  },
  verse: {
    fontSize: '18px',
    color: '#34495e',
    fontStyle: 'italic',
    lineHeight: '1.6',
    fontFamily: "'Poppins', sans-serif",
  },
};

export default RandomVerse;
