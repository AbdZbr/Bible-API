import { useState } from 'react';

function SpecificVerse() {
  const [verse, setVerse] = useState('');
  const [input, setInput] = useState('');

  const fetchSpecificVerse = async () => {
    try {
      const formattedInput = input.replace(/\s+/g, '+');
      const response = await fetch(`https://labs.bible.org/api/?passage=${formattedInput}&type=json`);
      const data = await response.json();
      const specificVerse = `${data[0].bookname} ${data[0].chapter}:${data[0].verse} - "${data[0].text}"`;
      setVerse(specificVerse);
    } catch (error) {
      console.error('Error fetching verse:', error);
      setVerse('Verse not found. Please check your input.');
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Find a Bible Verse</h2>
      <input 
        type="text" 
        placeholder="Enter verse (e.g., John 3:16)" 
        value={input} 
        onChange={(e) => setInput(e.target.value)} 
        style={styles.input}
      />
      <button onClick={fetchSpecificVerse} style={styles.button}>
        Get Verse
      </button>
      <div style={styles.verseContainer}>
        <p style={styles.verse}>{verse}</p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    maxWidth: '500px',
    margin: '0 auto',
    textAlign: 'center',
  },
  heading: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '20px',
    fontFamily: "'Poppins', sans-serif",
  },
  input: {
    padding: '12px 15px',
    fontSize: '16px',
    borderRadius: '8px',
    border: '1px solid #ccc',
    width: '100%',
    maxWidth: '300px',
    marginBottom: '15px',
    outline: 'none',
    fontFamily: "'Poppins', sans-serif",
  },
  button: {
    padding: '12px 20px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '16px',
    fontFamily: "'Poppins', sans-serif",
    transition: 'background-color 0.3s ease',
  },
  buttonHover: {
    backgroundColor: '#45a049',
  },
  verseContainer: {
    marginTop: '20px',
    padding: '10px 20px',
    backgroundColor: '#fff',
    borderRadius: '10px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    width: '100%',
    maxWidth: '400px',
    minHeight: '60px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  verse: {
    fontSize: '18px',
    color: '#333',
    fontStyle: 'italic',
    fontFamily: "'Poppins', sans-serif",
    lineHeight: '1.5',
  },
};

export default SpecificVerse;
